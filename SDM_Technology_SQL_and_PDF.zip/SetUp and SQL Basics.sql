CREATE DATABASE SDM_Employees;
USE SDM_Employees;
CREATE TABLE Departments (
    Domain_id INT PRIMARY KEY,
    Domain_name VARCHAR(50)
);
INSERT INTO Departments VALUES
(1,'Full Stack Developer') , (2,'Front End Developer') , (3,'Python Developer') , (4,'UI/UX Designer') , (5,'Graphic Designer') , 
(6,'AI/ML Engineer') , (7,'Data Scientist') , (8,'Content Writer') , (9,'Digital Marketing Executive') , (10,'SEO Speacialist');
CREATE TABLE Employees (
    Employee_id INT PRIMARY KEY,
    Employee_name VARCHAR(50),
    age INT,
    Domain_id INT,
    FOREIGN KEY (Domain_id)
        REFERENCES Departments (Domain_id)
);
INSERT INTO Employees VALUES
(101,'Sapna',22 ,7) , (102,'Sathi',20,1) , (103,'Sourav',20,4) , (104,'Sujit',22,7) , (105,'Arya',20,10) ,
(106,'Aman',21,1) , (107,'Anshi',22,4) , (108,'Sumit',21,10) , (109,'Riti',20,2) , (110,'Shreedep',20,2) , 
(111,'Ritesh',20,3) , (112,'Ahana',22,5) , (113,'Milan',23,6) , (114,'Megha',20,5) , (115,'Pradip',21,3) , 
(116,'Amit',20,6) , (117,'Sneha',21,8) , (118,'Sunil',20,9) , (119,'Ritika',23,9) , (120,'Ravi',21,8) ;
--  QUERY->01 [DISPLAY ALL RECORDS OF DEPARTMENTS AND EMPLOYEES]
SELECT 
    *
FROM
    Departments;
SELECT 
    *
FROM
    Employees;
--  QUERY->02 [DISPLAY NAMES OF EMPLOYEES AND THEIR DOMAIN IDs]
SELECT 
    Employee_name, Domain_id
FROM
    Employees;
--  QUERY->03 [DISPLAY NAMES OF EMPLOYEES WHOSE AGE IS MORE THAN 20]
SELECT 
    Employee_name, age
FROM
    Employees
WHERE
    age > 20;
--  QUERY->04 [DISPLAY NAMES OF EMPLOYEES IN ACCENDING ORDER OF THEIR DOMAIN IDs]
SELECT 
    Employee_name, Domain_id
FROM
    Employees
ORDER BY Domain_id ASC;
--  QUERY->05 [COUNT TOTAL NUMBER OF EMPLOYEES]
SELECT 
    COUNT(*) AS Total_Employees
FROM
    Employees;
--  QUERY->06 [DISPLAY EMPLOYEE NAMES WITH THEIR DOMAIN NAMES]
SELECT 
    e.Employee_name, d.Domain_name
FROM
    Employees e
        JOIN
    Departments d ON e.Domain_id = d.Domain_id;
--  QUERY->07 [DISPLAY EMPLOYEE NAMES WITH THEIR EMPLOYEE IDs WHOSE DOMAIN IS DATA SCIENTIST]
SELECT 
    e.Employee_name, d.Domain_id
FROM
    Employees e
        JOIN
    Departments d ON e.Domain_id = d.Domain_id
WHERE
    d.Domain_name = 'Data Scientist';
--  QUERY->08 [DISPLAY EMPLOYEE NAMES WITH THEIR DOMAIN NAME AND DOMAIN IDs WHOSE AGE IS LESS THAN OR EQUAL TO 21]
SELECT 
    e.Employee_name, d.Domain_name, d.Domain_id
FROM
    Employees e
        JOIN
    Departments d ON e.Domain_id = d.Domain_id
WHERE
    e.age <= 21;
--  QUERY->09 [DISPLAY EMPLOYEE NAMES WITH THEIR DOMAIN NAME WHO BELONGS TO THE DOMAIN OF FULL STACK DEVELOPER ]
SELECT 
    e.Employee_name, d.Domain_name
FROM
    Employees e
        JOIN
    Departments d ON e.Domain_id = d.Domain_id
WHERE
    d.Domain_name = 'Full Stack Developer';
--  QUERY->10 [DISPLAY ALL DEPARTMENTS WITH THIER ENPLOYEE NAMES ]
SELECT 
    d.Domain_name, e.Employee_name
FROM
    Departments d
        LEFT JOIN
    Employees e ON d.Domain_id = e.Domain_id;
--  QUERY->11 [COUNT OF NUMBER OF EMPLOYEES IN EACH DEPARTMENT]
SELECT 
    d.Domain_name, COUNT(e.Employee_id) AS Total_Employees
FROM
    Departments d
        LEFT JOIN
    Employees e ON d.Domain_id = e.Domain_id
GROUP BY d.Domain_id , d.Domain_name;
--  QUERY->12 [DISPLAY AVERAGE AGE OF EMPLOYEES FROM EACH DEPARTMENT]
SELECT 
    d.Domain_name, AVG(e.age) AS Average_Age
FROM
    Departments d
        JOIN
    Employees e ON d.Domain_id = e.Domain_id
GROUP BY d.Domain_id , d.Domain_name;
--  QUERY->13 [DISPLAY MAX AGE OF EMPLOYEES FROM EACH DEPARTMENT]
SELECT 
    d.Domain_name, MAX(e.age) AS Maximum_Age
FROM
    Departments d
        JOIN
    Employees e ON d.Domain_id = e.Domain_id
GROUP BY d.Domain_id , d.Domain_name;
--  QUERY->14 [DISPLAY MIN AGE OF EMPLOYEES FROM EACH DEPARTMENT]
SELECT 
    d.Domain_name, MIN(e.age) AS Minimum_Age
FROM
    Departments d
        JOIN
    Employees e ON d.Domain_id = e.Domain_id
GROUP BY d.Domain_id , d.Domain_name;
--  QUERY->15 [DISPLAY COUNT OF EMPLOYEE BY AGE]
SELECT 
    age, COUNT(*) AS Total_Employees
FROM
    Employees
GROUP BY age
ORDER BY age;